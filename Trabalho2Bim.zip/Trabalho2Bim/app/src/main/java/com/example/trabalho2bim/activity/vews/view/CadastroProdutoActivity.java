package com.example.trabalho2bim.activity.vews.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.trabalho2bim.R;

public class CadastroProdutoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_produto);
    }
}